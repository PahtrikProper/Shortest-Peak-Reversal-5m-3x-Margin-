"""Short-only margin call strategy utilities for Bybit linear futures."""

from .config import TraderConfig
from .main_engine import run  # noqa: F401
